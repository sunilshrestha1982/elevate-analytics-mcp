import { getPinoLogger } from '../lib/logger.js';

export interface Logger {
  info(message: string, meta?: unknown): void;
  warn(message: string, meta?: unknown): void;
  error(message: string, meta?: unknown): void;
}

export function createLogger(scope: string): Logger {
  const base = getPinoLogger();
  return {
    info: (message: string, meta?: unknown) => base.info({ scope, meta }, message),
    warn: (message: string, meta?: unknown) => base.warn({ scope, meta }, message),
    error: (message: string, meta?: unknown) => base.error({ scope, meta }, message),
  };
}
