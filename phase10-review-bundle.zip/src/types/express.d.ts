declare global {
  namespace Express {
    interface Request {
      auth?: {
        userId: number;
        token: string;
        authenticated: boolean;
      };
      context?: {
        requestId: string;
        startTime: number;
        userId: number;
      };
    }
  }
}

export {};
