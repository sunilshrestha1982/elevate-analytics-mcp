import express from 'express';
import cookieParser from 'cookie-parser';
import dotenv from 'dotenv';
import { pinoHttp } from 'pino-http';
import type { IncomingMessage } from 'node:http';
import { healthRouter } from './routes/health.js';
import { userRouter } from './routes/users.js';
import { oauthRouter } from './routes/oauth.js';
import { env, validateRequiredEnvOnStartup } from './config/env.js';
import { getPinoLogger, logger } from './lib/logger.js';
import { getMetricsRegistry, getNodeStatsSnapshot, observeRequestDuration } from './lib/metrics.js';
import { applySecurityMiddleware } from './middleware/security.js';
import { databaseService } from './services/databaseService.js';
import { requestTimeoutMiddleware } from './middleware/requestTimeout.js';
import { inputSanitizationMiddleware } from './middleware/inputSanitization.js';

dotenv.config();
validateRequiredEnvOnStartup();

const app = express();

applySecurityMiddleware(app);
app.use(
  pinoHttp({
    logger: getPinoLogger(),
    customSuccessMessage: (req: IncomingMessage) => `request completed: ${req.method} ${req.url}`,
    customErrorMessage: (req: IncomingMessage) => `request failed: ${req.method} ${req.url}`,
  })
);
app.use(requestTimeoutMiddleware);
app.use(inputSanitizationMiddleware);

app.use((req, res, next) => {
  const start = process.hrtime.bigint();
  res.on('finish', () => {
    const durationMs = Number(process.hrtime.bigint() - start) / 1_000_000;
    observeRequestDuration(req.method, req.route?.path ?? req.path, res.statusCode, durationMs);
    logger.info('HTTP request duration', {
      method: req.method,
      path: req.path,
      statusCode: res.statusCode,
      durationMs: Number(durationMs.toFixed(2)),
    });
  });
  next();
});

app.use(express.json());
app.use(cookieParser(env.SESSION_SECRET));
app.use('/health', healthRouter);
app.use('/users', userRouter);
app.use('/oauth', oauthRouter);

app.get('/ready', async (_req, res) => {
  const health = await databaseService.checkHealth();
  res.status(health.status === 'ok' ? 200 : 503).json({
    status: health.status === 'ok' ? 'ready' : 'not_ready',
    dependencies: { database: health.status },
    timestamp: new Date().toISOString(),
  });
});

app.get('/live', (_req, res) => {
  res.status(200).json({ status: 'alive', timestamp: new Date().toISOString() });
});

app.get('/version', (_req, res) => {
  res.status(200).json({
    name: 'elevate-analytics-mcp',
    version: env.APP_VERSION,
    nodeEnv: env.NODE_ENV,
  });
});

app.get('/metrics', async (req, res) => {
  if (env.METRICS_AUTH_TOKEN) {
    const auth = req.get('authorization')?.replace(/^Bearer\s+/i, '');
    if (auth !== env.METRICS_AUTH_TOKEN) {
      return res.status(401).json({ error: 'Unauthorized' });
    }
  }

  const registry = getMetricsRegistry();
  res.setHeader('Content-Type', registry.contentType);
  return res.status(200).send(await registry.metrics());
});

app.get('/', (_req, res) => {
  res.json({ message: 'Elevate Analytics MCP server is running', stats: getNodeStatsSnapshot() });
});

const server = app.listen(env.PORT, () => {
  logger.info('Server listening', {
    port: env.PORT,
    nodeEnv: env.NODE_ENV,
    trustProxy: env.TRUST_PROXY,
    rateLimitPerMinute: env.RATE_LIMIT_PER_MINUTE,
  });
});

let isShuttingDown = false;
const shutdown = async (signal: string) => {
  if (isShuttingDown) return;
  isShuttingDown = true;
  logger.info('Graceful shutdown started', { signal });
  server.close(async () => {
    await databaseService.disconnect();
    logger.info('Graceful shutdown complete');
    process.exit(0);
  });

  setTimeout(() => {
    logger.error('Force exit after shutdown timeout');
    process.exit(1);
  }, 10_000).unref();
};

process.on('SIGINT', () => {
  void shutdown('SIGINT');
});
process.on('SIGTERM', () => {
  void shutdown('SIGTERM');
});

export { app, server };
