export interface SearchConsoleCacheEntry<T> {
  value: T;
  expiresAt: number;
}

export class InMemorySearchConsoleCache {
  private readonly values = new Map<string, SearchConsoleCacheEntry<unknown>>();

  get<T>(key: string): T | undefined {
    const entry = this.values.get(key);
    if (!entry) return undefined;
    if (entry.expiresAt <= Date.now()) {
      this.values.delete(key);
      return undefined;
    }
    return entry.value as T;
  }

  set<T>(key: string, value: T, ttlMs: number): void {
    this.values.set(key, { value, expiresAt: Date.now() + ttlMs });
  }

  delete(key: string): void {
    this.values.delete(key);
  }
}
