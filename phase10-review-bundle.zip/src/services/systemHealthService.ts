import { z } from 'zod';
import { env } from '../config/env.js';
import { databaseService } from './databaseService.js';

const componentSchema = z.object({
  status: z.enum(['ok', 'error']),
  message: z.string(),
});

const healthResponseSchema = z.object({
  status: z.enum(['ok', 'degraded', 'error']),
  timestamp: z.string(),
  components: z.object({
    database: componentSchema,
    oauth: componentSchema,
    searchConsole: componentSchema,
    ga4: componentSchema,
  }),
});

export type HealthResponse = z.infer<typeof healthResponseSchema>;

function checkConfigured(value: string | undefined, name: string) {
  if (!value) {
    return { status: 'error' as const, message: `${name} is not configured` };
  }
  return { status: 'ok' as const, message: `${name} configured` };
}

export class SystemHealthService {
  async getHealth(): Promise<HealthResponse> {
    const db = await databaseService.checkHealth();
    const oauth = [
      checkConfigured(env.GOOGLE_CLIENT_ID, 'GOOGLE_CLIENT_ID'),
      checkConfigured(env.GOOGLE_CLIENT_SECRET, 'GOOGLE_CLIENT_SECRET'),
      checkConfigured(env.GOOGLE_REDIRECT_URI, 'GOOGLE_REDIRECT_URI'),
    ];

    const oauthStatus = oauth.every((item) => item.status === 'ok') ? 'ok' : 'error';
    const searchConsoleStatus = oauthStatus;
    const ga4Status = oauthStatus;

    const response: HealthResponse = {
      status: db.status === 'ok' && oauthStatus === 'ok' ? 'ok' : db.status === 'ok' ? 'degraded' : 'error',
      timestamp: new Date().toISOString(),
      components: {
        database: {
          status: db.status === 'ok' ? 'ok' : 'error',
          message: db.status === 'ok' ? 'database connected' : 'database not reachable',
        },
        oauth: {
          status: oauthStatus,
          message: oauthStatus === 'ok' ? 'oauth configured' : oauth.filter((item) => item.status === 'error').map((item) => item.message).join(', '),
        },
        searchConsole: {
          status: searchConsoleStatus,
          message: searchConsoleStatus === 'ok' ? 'search console dependency configured' : 'search console dependency not configured',
        },
        ga4: {
          status: ga4Status,
          message: ga4Status === 'ok' ? 'ga4 dependency configured' : 'ga4 dependency not configured',
        },
      },
    };

    return healthResponseSchema.parse(response);
  }
}

export const systemHealthService = new SystemHealthService();
