import pino from 'pino';

const pinoLogger = pino({
  level: process.env.LOG_LEVEL ?? 'info',
  base: {
    service: 'elevate-analytics-mcp',
    env: process.env.NODE_ENV ?? 'development',
  },
  timestamp: pino.stdTimeFunctions.isoTime,
});

export const logger = {
  info: (message: string, meta?: unknown) => {
    if (meta !== undefined) {
      pinoLogger.info({ meta }, message);
      return;
    }
    pinoLogger.info(message);
  },
  warn: (message: string, meta?: unknown) => {
    if (meta !== undefined) {
      pinoLogger.warn({ meta }, message);
      return;
    }
    pinoLogger.warn(message);
  },
  error: (message: string, meta?: unknown) => {
    if (meta !== undefined) {
      pinoLogger.error({ meta }, message);
      return;
    }
    pinoLogger.error(message);
  },
};

export const getPinoLogger = () => pinoLogger;
