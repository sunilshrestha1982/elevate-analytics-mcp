import { prisma, disconnectPrisma } from '../lib/prisma.js';
import { logger } from '../lib/logger.js';
import { UserRepository } from '../repositories/userRepository.js';
import { GoogleAccountRepository } from '../repositories/googleAccountRepository.js';
import { OAuthSessionRepository } from '../repositories/oauthSessionRepository.js';

export class DatabaseService {
  public readonly userRepository = new UserRepository();
  public readonly googleAccountRepository = new GoogleAccountRepository();
  public readonly oauthSessionRepository = new OAuthSessionRepository();

  async checkHealth() {
    try {
      await prisma.$queryRaw`SELECT 1`;
      return {
        status: 'ok',
        service: 'database',
        timestamp: new Date().toISOString(),
      };
    } catch (error) {
      logger.error('Database health check failed', error);
      return {
        status: 'error',
        service: 'database',
        timestamp: new Date().toISOString(),
        error: error instanceof Error ? error.message : 'Unknown database error',
      };
    }
  }

  async disconnect() {
    await disconnectPrisma();
  }
}

export const databaseService = new DatabaseService();
