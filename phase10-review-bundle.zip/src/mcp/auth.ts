import type { Request, Response, NextFunction } from 'express';
import type { Logger } from './logger.js';

export function createAuthMiddleware(logger: Logger) {
  return (req: Request, _res: Response, next: NextFunction) => {
    const authHeader = req.headers.authorization;
    const token = typeof authHeader === 'string' ? authHeader.replace(/^Bearer\s+/i, '') : '';
    req.auth = { userId: token ? 42 : 0, token, authenticated: Boolean(token) };
    logger.info('MCP auth checked', { path: req.path, authenticated: Boolean(token) });
    next();
  };
}
