import { describe, expect, it } from 'vitest';
import request from 'supertest';
import { createMcpApp } from './server.js';

describe('MCP server', () => {
  it('serves health and version endpoints', async () => {
    const { app } = createMcpApp();
    const health = await request(app).get('/health');
    const version = await request(app).get('/version');
    expect(health.status).toBe(200);
    expect(version.status).toBe(200);
  });

  it('supports MCP discovery', async () => {
    const { app } = createMcpApp();
    const response = await request(app).get('/mcp');
    expect(response.status).toBe(200);
    expect(response.body.protocol).toBe('mcp');
  });
});
